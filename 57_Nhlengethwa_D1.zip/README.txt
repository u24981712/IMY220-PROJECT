https://github.com/u24981712/IMY220-PROJECT.git

Project is accessible in branch_d1

******DEFAULT USER******

"email": "u24981712@tuks.co.za"
"password": "123456789@"

***************************